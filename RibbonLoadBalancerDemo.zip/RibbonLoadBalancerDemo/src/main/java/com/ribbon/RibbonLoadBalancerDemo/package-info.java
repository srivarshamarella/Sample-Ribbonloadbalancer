package com.ribbon.RibbonLoadBalancerDemo;

/*To access this service in browser type 
http://localhost:9080/rlbcustomers 
*/
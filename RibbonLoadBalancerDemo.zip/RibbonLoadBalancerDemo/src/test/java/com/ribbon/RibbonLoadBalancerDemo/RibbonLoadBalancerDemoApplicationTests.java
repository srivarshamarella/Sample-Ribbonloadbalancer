package com.ribbon.RibbonLoadBalancerDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RibbonLoadBalancerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
